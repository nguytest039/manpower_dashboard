function applyResponsiveRules(config) {
    const responsiveRules = {
        rules: [
            {
                condition: { maxWidth: 600 },
                chartOptions: {
                    legend: { enabled: false },
                    xAxis: {
                        labels: { style: { fontSize: '10px' } },
                    },
                    yAxis: {
                        labels: { style: { fontSize: '10px' } },
                    },
                    plotOptions: {
                        series: {
                            dataLabels: { style: { fontSize: '10px' } },
                        },
                    },
                },
            },
        ],
    };

    return {
        ...config,
        responsive: responsiveRules,
    };
}

Highcharts.chart(
    'testchart',
    applyResponsiveRules({
        chart: {
            backgroundColor: 'transparent',
            type: 'column',
        },
        title: null,
        yAxis: {
            gridLineWidth: 0,
            labels: {
                style: {
                    color: '#fff',
                },
            },
            title: null,
        },
        xAxis: {
            categories: ['Apples', 'Oranges', 'Pears', 'Grapes', 'Bananas'],
            labels: {
                style: {
                    color: '#fff',
                },
            },
            lineWidth: 0,
        },
        credits: {
            enabled: false,
        },
        legend: {
            itemStyle: {
                color: '#fff',
            },
            y: 22,
        },
        plotOptions: {
            column: {
                borderWidth: 0,
            },
            series: {
                dataLabels: {
                    enabled: true,
                    style: {
                        color: '#fff',
                        textOutline: 'none',
                    },
                },
            },
        },
        series: [
            {
                name: 'John',
                data: [-15, -13, 14, 17, 12],
                color: '#A07641',
            },
            {
                name: 'Jane',
                data: [12, -12, -13, 12, 11],
                color: '#A0ADAB',
            },
            {
                name: 'Joe',
                data: [13, 14, 14, -12, 15],
                color: '#2E7E6E',
            },
            {
                name: 'Duke',
                data: [15, 13, 17, 17, 20],
                color: '#64ADBF',
            },
            {
                name: 'Mai',
                data: [15, 13, 14, 7, -20],
                color: '#9FB53D',
            },
        ],
    })
);

Highcharts.chart(
    'donut',
    applyResponsiveRules({
        chart: {
            backgroundColor: 'transparent',
            type: 'pie',
            custom: {},
            events: {
                render() {
                    const chart = this,
                        series = chart.series[0];
                    let customLabel = chart.options.chart.custom.label;

                    if (!customLabel) {
                        customLabel = chart.options.chart.custom.label = chart.renderer
                            .label('<strong>2 877 820</strong>')
                            .css({
                                color: 'var(--highcharts-neutral-color-100, #fff)',
                                textAnchor: 'middle',
                            })
                            .add();
                    }

                    const x = series.center[0] + chart.plotLeft,
                        y = series.center[1] + chart.plotTop - customLabel.attr('height') / 2;

                    customLabel.attr({
                        x,
                        y,
                    });
                    customLabel.css({
                        fontSize: `${series.center[2] / 12}px`,
                    });
                },
            },
        },
        accessibility: {
            point: {
                valueSuffix: '%',
            },
        },
        title: null,
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.0f}%</b>',
        },
        legend: {
            enabled: false,
        },
        plotOptions: {
            series: {
                allowPointSelect: true,
                cursor: 'pointer',
                borderRadius: 0,
                borderWidth: 0,
                dataLabels: [
                    {
                        enabled: true,
                        distance: 20,
                        format: '{point.name}',
                        style: {
                            color: '#fff',
                            textOutline: 'none',
                        },
                    },
                    {
                        enabled: false,
                        distance: -15,
                        format: '{point.percentage:.0f}%',
                        style: {
                            fontSize: '0.9em',
                            color: '#fff',
                            textOutline: 'none',
                        },
                    },
                ],
                showInLegend: true,
            },
        },

        series: [
            {
                name: 'Registrations',
                colorByPoint: true,
                innerSize: '75%',
                data: [
                    {
                        name: 'EV',
                        y: 23.9,
                    },
                    {
                        name: 'Hybrids',
                        y: 12.6,
                    },
                    {
                        name: 'Diesel',
                        y: 37.0,
                    },
                    {
                        name: 'Petrol',
                        y: 26.4,
                    },
                ],
            },
        ],
    })
);
